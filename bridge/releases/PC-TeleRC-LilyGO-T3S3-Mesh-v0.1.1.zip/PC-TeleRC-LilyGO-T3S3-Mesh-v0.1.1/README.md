# TeleRC Mesh 0.1.1 — optimized direct-pair bench candidate

Flash gateway AND rover, then set radio legs = 1 on BOTH boards. Existing saved profiles retain their older leg setting; one leg activates the faster direct profile. For relays select matching two or three legs on every participant.

Start with bridge/TeleRCMesh/README.md for wiring, configuration and flash instructions. Source files are in bridge/TeleRCMesh/. Both adjacent headers must stay beside TeleRCMesh.ino. The normal Arduino sketch upload preserves stored profiles. firmware/TeleRCMesh.ino.merged.bin is a factory image for the exact pinned T3-S3 SX1262 profile; it clears NVS settings and requires provisioning again.

The 500 ms independent channel deadline, neutral restart requirement, packet authentication and no automatic ARM behavior are retained. Direct poll wait is 100 ms; response window is 90 ms. Relay timing stays 370/350 ms. Boosted RX gain is enabled; its range benefit is unmeasured. No PC application or downstream FC/motor firmware is included or changed.

Simulated representative direct results: 135 ms average input-to-UART delay, 200 ms P95, 7.76 Hz. With 1% independent RF packet loss, 0.343% of one-minute sessions stopped, compared with 95.1% under the previous timing. These are simulation results, not guarantees for a real channel or rover. Channel occupancy is higher and burst losses still cause stops.

bridge/simulation/README.md explains assumptions and limits; its results/ folder contains raw tables and the comparison chart. To reproduce from this package root, install bridge/simulation/requirements.txt and run python3 bridge/simulation/simulate_direct.py --output bridge/simulation/results. Host regressions can be run with bridge/tests/run_mesh.sh on Linux with g++ and libssl-dev.

Actual target build, host regression, ASan/UBSan and model reference comparisons pass. Read bridge/TeleRCMesh/VERIFY.md. Physical RF, latency, stop, takeover and brownout validation remain open. Restrain the rover before bench testing. This package is a bench-test candidate, not a stable release.
