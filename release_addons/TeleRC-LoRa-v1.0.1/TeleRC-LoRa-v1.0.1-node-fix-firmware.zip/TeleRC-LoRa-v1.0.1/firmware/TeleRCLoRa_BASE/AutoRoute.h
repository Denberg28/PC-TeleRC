#pragma once
#include <stdint.h>
namespace autoroute {
// Bit 0: Node 1, bit 1: Node 2. Probe directed paths without flooding.
constexpr uint8_t PROFILES[4]={0,1,2,3};
constexpr uint8_t legs(uint8_t mask){return 1+uint8_t(bool(mask&1))+uint8_t(bool(mask&2));}
inline const char* name(uint8_t mask){return mask==0?"DIRECT":mask==1?"VIA NODE 1":mask==2?"VIA NODE 2":"VIA N1 AND N2";}
struct Discovery {
 uint8_t index=0,misses=0;bool locked=false;
 uint8_t mask()const{return PROFILES[index];}
 void connected(){locked=true;misses=0;}
 bool missed(){
  if(locked&&++misses<3)return false;
  locked=false;misses=0;index=(index+1)%4;return true;
 }
 void reset(){index=misses=0;locked=false;}
};
}
