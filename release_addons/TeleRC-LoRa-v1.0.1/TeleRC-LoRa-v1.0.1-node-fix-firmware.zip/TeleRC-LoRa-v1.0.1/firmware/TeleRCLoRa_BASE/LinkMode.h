#pragma once
// ROVER first-boot default only. Saved physical BOOT menu selection wins.
// Wi-Fi and LoRa are exclusive; there is no automatic transport switching.
#ifndef TELERC_TRANSPORT_WIFI
#define TELERC_TRANSPORT_WIFI 0
#endif
#if TELERC_TRANSPORT_WIFI != 0 && TELERC_TRANSPORT_WIFI != 1
#error "TELERC_TRANSPORT_WIFI must be 0 (LoRa) or 1 (Wi-Fi)"
#endif
