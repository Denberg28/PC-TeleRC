#pragma once
#include "MeshCore.h"
namespace nodestate {
constexpr uint32_t READY_MS=20000,ACTIVE_MS=1500,NETWORK_MS=2500;
struct Relay {
 struct Pending {mesh::Challenge challenge;uint8_t route=0,kind=0;};
 Pending pending[4];uint8_t next=0;
 bool heard=false,confirmed=false,active=false;
 uint32_t heardAt=0,confirmedAt=0,activeAt=0;
 void observed(uint32_t now){heard=true;heardAt=now;}
 void forwarded(const mesh::Packet&p,uint32_t now){
  auto&s=pending[next];next=(next+1)%4;s.route=p.route;s.kind=p.kind;
  s.challenge.issue(p.token,now,mesh::timing(p.limit).responseMs);
 }
 bool reply(const mesh::Packet&p,uint32_t now){
  for(auto&s:pending)if(s.route==p.route&&mesh::replyKind(s.kind)==p.kind&&s.challenge.consume(p.token,now)){
   confirmed=true;confirmedAt=now;
   if(p.kind==mesh::COMMAND){active=true;activeAt=now;}
   return true;
  }
  return false;
 }
 const char*status(uint32_t now)const{
  if(active&&uint32_t(now-activeAt)<ACTIVE_MS)return "NODE FORWARDING";
  if(confirmed&&uint32_t(now-confirmedAt)<READY_MS)return "NODE READY";
  if(heard&&uint32_t(now-heardAt)<NETWORK_MS)return "NODE STANDBY";
  return "WAITING NETWORK";
 }
};
}
