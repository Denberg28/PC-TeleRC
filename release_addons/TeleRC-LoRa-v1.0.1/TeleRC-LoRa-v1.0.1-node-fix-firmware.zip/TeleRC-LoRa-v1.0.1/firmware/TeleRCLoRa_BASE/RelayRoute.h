#pragma once
#include "SketchSettings.h"
#include "MeshCore.h"
#include "AutoRoute.h"
namespace relay {
inline uint8_t chain(uint8_t mask,uint16_t*out){
 uint8_t n=0;out[n++]=1;
 if(mask&1)out[n++]=3;
 if(mask&2)out[n++]=4;
 out[n++]=2;return n;
}
inline bool addressedTo(const mesh::Packet&p,uint16_t self){
 if(p.network!=TELERC_NETWORK_ID||p.route>3||p.limit!=autoroute::legs(p.route))return false;
 const bool poll=mesh::upstream(p.kind);
 if(poll?(p.origin!=2||p.dest!=1):(!mesh::downstream(p.kind)||p.origin!=1||p.dest!=2))return false;
 uint16_t path[4];uint8_t n=chain(p.route,path);
 for(uint8_t i=0;i<n;++i)if(path[i]==self){
  if(poll)return i+1<n&&p.sender==path[i+1]&&p.hops==i+1;
  return i>0&&p.sender==path[i-1]&&p.hops==n-i;
 }
 return false;
}
inline bool addressed(const mesh::Packet&p){return addressedTo(p,settings::SELF);}
inline bool forwardAs(mesh::Packet&p,uint16_t self){
 if((self!=3&&self!=4)||!addressedTo(p,self)||p.hops<=1)return false;
 --p.hops;p.sender=self;return true;
}
inline bool forward(mesh::Packet&p){return TELERC_ROLE==2&&forwardAs(p,settings::SELF);}
}
