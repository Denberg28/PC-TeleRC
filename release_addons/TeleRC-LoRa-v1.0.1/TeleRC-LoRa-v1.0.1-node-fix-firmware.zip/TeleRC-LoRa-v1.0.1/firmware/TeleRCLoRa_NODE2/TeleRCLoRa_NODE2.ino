// TeleRC 1.0.1 - upload all LoRa participants from this package together.
// Automatic directed routes: direct, Node 1, Node 2, or Node 1 + Node 2.
#define TELERC_LORA_PASSWORD "telerc123"  // 9 characters; change on ALL boards
#define TELERC_LORA_FREQUENCY_KHZ 915000
#define TELERC_LORA_POWER_DBM 2           // 2..17; match hardware/permitted limits
#define TELERC_NETWORK_ID 1              // Same network ID on all four boards
#define TELERC_NODE_INDEX 2
#define TELERC_ROLE 2
#include "Runtime.h"
void setup(){runtime::setup();}
void loop(){runtime::loop();}
