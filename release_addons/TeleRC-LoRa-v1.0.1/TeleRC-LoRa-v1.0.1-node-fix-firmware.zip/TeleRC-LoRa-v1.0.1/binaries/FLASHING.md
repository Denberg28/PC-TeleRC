# Optional compiled factory images — v1.0.1

These are target-compiled, full 4 MB factory images for **LilyGo T3-S3 SX1262**,
ESP32-S3, Hardware CDC/JTAG, USB CDC enabled, QSPI PSRAM enabled, default
partition scheme. The rover image includes both transport backends and starts
in LoRa when no saved mode exists. Credentials are the defaults in READ-ME-FIRST.

**A factory image overwrites the complete 4 MB flash, including saved transport
and other NVS settings.** Use Arduino IDE source upload without flash erase to
preserve those settings instead. Compiled images do not include any edits you
make to the source; compile/upload again after changing credentials.

With motor power disconnected and antennas fitted, install esptool 5.1.0 if
needed, then use your actual COM port. From the extracted package folder:

```powershell
python -m pip install esptool==5.1.0
python -m esptool --chip esp32s3 --port COM9 write-flash 0x0 binaries/TeleRCLoRa_BASE-v1.0.1-factory.bin
```

For each other board, change the port and filename:

| Board | Factory image |
| --- | --- |
| ROVER | `TeleRCLoRa_ROVER-v1.0.1-factory.bin` |
| NODE1 | `TeleRCLoRa_NODE1-v1.0.1-factory.bin` |
| NODE2 | `TeleRCLoRa_NODE2-v1.0.1-factory.bin` |

Close PC TeleRC and Serial Monitor first. If the bootloader cannot connect,
hold BOOT, press/release RESET, release BOOT, then retry. Reset normally with
BOOT released after flashing. The attached board must match the chosen role.
All LoRa participants must use this v1.0.1 radio protocol v4 package.

SHA256SUMS.txt records each image and source file. Target compilation does not
mean these factory images have been flashed or tested on real boards here.
