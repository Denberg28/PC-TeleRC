#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
# Install once: arduino-cli core install esp32:esp32@3.3.2
#               arduino-cli lib install RadioLib@7.2.1
fqbn='esp32:esp32:lilygo_t3s3:CDCOnBoot=cdc,USBMode=hwcdc,PSRAM=enabled,Revision=Radio_SX1262'
for role in BASE ROVER NODE1 NODE2; do
  arduino-cli compile --fqbn "$fqbn" --output-dir "build/$role" "firmware/TeleRCLoRa_$role"
done
