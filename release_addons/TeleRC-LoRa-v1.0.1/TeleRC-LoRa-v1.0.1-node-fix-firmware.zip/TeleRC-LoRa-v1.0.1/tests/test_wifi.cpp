#include <cassert>
#include <iostream>
#include "WiFiLink.h"
static unsigned checks=0;
#define CHECK(x) do {assert(x);++checks;} while(0)
std::vector<uint8_t> rc(uint16_t x,uint16_t y){
 std::vector<uint8_t> f(26);stopMask=3;makeStopFrame(f.data(),1500);stopMask=0;
 mesh::put16(f.data()+6,x);mesh::put16(f.data()+8,y);telerc::CommandMailbox::checksumRc(f.data());return f;
}
void reset(){
 fakeNow=100;WiFi={};udp={};safety={};peer=NO_PEER;
 vehicle.bytes.clear();vehicle.room=1024;vehicle.shortNext=false;
 apReady=udpReady=haveFc=false;stopMask=0;fcAt=0;
 apAt=udpAt=fakeNow-WIFI_RETRY_MS;apCheckAt=peerAt=0;
}
int main(){
 reset();serviceWifi();CHECK(apReady&&udpReady);CHECK(WiFi.starts==1);
 WiFi.stations=0;fakeNow+=5000;serviceWifi();CHECK(WiFi.starts==1); // Stable AP never cycles for absent clients.
 WiFi.currentMode=WIFI_OFF;fakeNow+=1001;serviceWifi();CHECK(apReady&&udpReady&&WiFi.starts==2);
 reset();serviceWifi();auto center=rc(1500,1500),drive=rc(1700,1700);
 CHECK(!acceptHost(center.data(),center.size()));haveFc=true;fcAt=fakeNow;
 CHECK(!acceptHost(drive.data(),drive.size()));CHECK(acceptHost(center.data(),center.size()));CHECK(safety.owned==3);
 vehicle.shortNext=true;CHECK(!acceptHost(drive.data(),drive.size()));CHECK(!safety.owned);
 reset();serviceWifi();haveFc=true;fcAt=fakeNow;udp.in=center;udp.port=1234;pumpUdp();CHECK(!safety.owned&&peer==NO_PEER);
 udp.port=14550;udp.in=center;udp.sender=IPAddress(10,0,0,2);pumpUdp();CHECK(!safety.owned);
 udp.sender=IPAddress(192,168,4,2);udp.in=center;pumpUdp();CHECK(safety.owned==3&&peer==udp.sender);
 udp.sender=IPAddress(192,168,4,3);udp.in=drive;pumpUdp();CHECK(safety.value[0]==1500); // Locked to original peer.
 fakeNow+=500;loop();CHECK(!safety.owned); // Heartbeats and clients do not renew the axes.
 std::cout<<checks<<" Wi-Fi checks passed\n";
}
