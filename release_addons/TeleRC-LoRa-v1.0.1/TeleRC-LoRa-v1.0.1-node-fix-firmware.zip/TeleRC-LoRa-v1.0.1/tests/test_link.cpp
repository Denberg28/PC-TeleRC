#include <cassert>
#include <iostream>
#define TELERC_ROLE 3
#define TELERC_RUNTIME_MENU 1
#include "Link.h"
static unsigned checks=0;
#define CHECK(x) do {assert(x);++checks;} while(0)
std::vector<uint8_t> bundle(uint16_t x,uint16_t y){
 std::vector<uint8_t> b(27);b[0]=26;makeRc(b.data()+1,1500,0);
 mesh::put16(b.data()+7,x);mesh::put16(b.data()+9,y);telerc::CommandMailbox::checksumRc(b.data()+1);return b;
}
void reset(){
 safety={};commands={};seen={};challenge={};discovery={};activeRoute=0;
 vehicle.bytes.clear();vehicle.room=1024;vehicle.shortNext=false;Serial.bytes.clear();Serial.room=1024;
 haveFc=true;fcAt=fakeNow=100;radioOK=true;maintenance=transmitting=scanning=awaitingReply=stopPending=false;
 clearQueue();usbHead=usbTail=usbCount=0;cfg=Config{};cfg.key[0]=1;cfg.khz=915000;
}
void uartSafety(){
 reset();auto center=bundle(1500,1500),drive=bundle(1700,1800);
 acceptCommands(drive.data(),drive.size());CHECK(vehicle.bytes.empty()&&!safety.owned);
 vehicle.shortNext=true;acceptCommands(center.data(),center.size());CHECK(!safety.owned);CHECK(lastReason==5);
 CHECK(vehicle.bytes.size()==25+52);CHECK(mesh::u16(vehicle.bytes.data()+25+6)==1500);CHECK(mesh::u16(vehicle.bytes.data()+51+6)==0);
 reset();acceptCommands(center.data(),center.size());CHECK(safety.owned==3);
 vehicle.room=0;stopControl(1);CHECK(stopPending&&!safety.ready);vehicle.room=1024;tryStop();CHECK(!stopPending);
 reset();std::vector<uint8_t> mixed=center;auto release=bundle(0,0);mixed.insert(mixed.end(),release.begin(),release.end());
 acceptCommands(mixed.data(),mixed.size());CHECK(!safety.owned);CHECK(vehicle.bytes.empty());
 reset();haveFc=false;acceptCommands(center.data(),center.size());CHECK(vehicle.bytes.empty());
}
void radioRecovery(){
 reset();radioFault();CHECK(!radioOK);CHECK(!safety.owned);radio.beginResult=-1;int before=radio.beginCalls;
 fakeNow+=1999;recoverRadio();CHECK(radio.beginCalls==before);
 fakeNow+=1;recoverRadio();CHECK(radio.beginCalls==before+1&&!radioOK);
 radio.beginResult=0;fakeNow+=2000;recoverRadio();CHECK(radioOK&&!safety.owned);
 maintenance=true;radioOK=false;fakeNow+=4000;before=radio.beginCalls;recoverRadio();CHECK(radio.beginCalls==before);
}
void partialUsb(){
 reset();const uint8_t in[]={3,4,5};CHECK(usbSend(in,3,true));Serial.room=2;serviceUsbTx();CHECK(Serial.bytes.size()==2);
 fakeNow+=300;Serial.room=32;serviceUsbTx();CHECK(Serial.bytes.size()==9);CHECK(usbCount==0);
 telerc::UartParser parser;unsigned complete=0;for(auto b:Serial.bytes)complete+=parser.feed(b,fakeNow);CHECK(complete==1);
 reset();CHECK(usbSend(in,3,true));fakeNow+=201;serviceUsbTx();CHECK(Serial.bytes.empty()&&usbCount==0);
}
void pathFailover(){
 reset();discovery.connected();challenge.issue(99,fakeNow,90);awaitingReply=true;pollAt=fakeNow;
 fakeNow+=91;sendPoll();CHECK(discovery.mask()==0&&discovery.misses==1);
 clearQueue();challenge.issue(100,fakeNow,90);awaitingReply=true;fakeNow+=101;sendPoll();CHECK(discovery.mask()==0&&discovery.misses==2);
 clearQueue();challenge.issue(101,fakeNow,90);awaitingReply=true;fakeNow+=101;sendPoll();CHECK(discovery.mask()==1&&!discovery.locked);
 reset();activeRoute=2;challenge.issue(777,fakeNow,220);awaitingReply=true;
 auto p=makePacket(mesh::COMMAND,777);p.origin=1;p.sender=4;p.dest=2;p.hops=1;
 uint8_t bytes[mesh::MAX];size_t n=mesh::seal(p,cfg.key,bytes);radio.incoming.assign(bytes,bytes+n);radioIRQ=true;pumpRadio();
 CHECK(discovery.locked&&!awaitingReply);CHECK(!safety.owned); // Empty link reply cannot drive.
 reset();challenge.issue(777,fakeNow,90);awaitingReply=true;
 p=makePacket(mesh::COMMAND,778);p.origin=p.sender=1;p.dest=2;p.hops=1;
 n=mesh::seal(p,cfg.key,bytes);radio.incoming.assign(bytes,bytes+n);radioIRQ=true;pumpRadio();CHECK(!discovery.locked&&awaitingReply);
}
int main(){uartSafety();radioRecovery();partialUsb();pathFailover();std::cout<<checks<<" link checks passed\n";}
