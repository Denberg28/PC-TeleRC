#include "Arduino.h"
#include "MeshCore.h"
#include "role_api.h"
#include <cassert>
#include <iostream>
#include <cstring>
static unsigned checks=0;
#define CHECK(x) do {assert(x);++checks;} while(0)
RoleApi base,rover,node1,node2;
mesh::Packet decode(const std::vector<uint8_t>&bytes){uint8_t key[32]={1};mesh::Packet p;CHECK(mesh::open(bytes.data(),bytes.size(),key,p));return p;}
void initialize(){fakeNow=100;fakeDio=LOW;base=baseApi();rover=roverApi();node1=node1Api();node2=node2Api();base.reset();rover.reset();node1.reset();node2.reset();}
std::vector<uint8_t> take(RoleApi a){std::vector<uint8_t>b;CHECK(a.emit(b));return b;}
void direct(){
 rover.poll();auto p=take(rover);node1.receive(p);node2.receive(p);base.receive(p);
 auto reply=take(base);rover.receive(reply);CHECK(rover.snapshot().locked);CHECK(rover.snapshot().route==0);
 CHECK(std::strcmp(node1.snapshot().status,"NODE STANDBY")==0);
 CHECK(std::strcmp(node2.snapshot().status,"NODE STANDBY")==0);
}
void finishProbe(uint8_t expected){
 rover.background();auto p=take(rover);auto packet=decode(p);CHECK(packet.kind==mesh::PROBE&&packet.route==expected&&packet.n==0);
 if(expected&2){node2.receive(p);p=take(node2);}
 if(expected&1){node1.receive(p);p=take(node1);}
 base.receive(p);p=take(base);packet=decode(p);CHECK(packet.kind==mesh::PROBE_REPLY&&packet.n==0);
 if(expected&1){node1.receive(p);p=take(node1);}
 if(expected&2){node2.receive(p);p=take(node2);}
 rover.receive(p);CHECK(!rover.snapshot().probeWaiting);CHECK(rover.snapshot().route==0);CHECK(!rover.snapshot().owned);
}
void joinsAndRejoins(){
 initialize();direct();fakeNow=3100;finishProbe(1);CHECK(rover.snapshot().known1);CHECK(std::strcmp(node1.snapshot().status,"NODE READY")==0);
 fakeNow=6200;finishProbe(2);CHECK(rover.snapshot().known2);CHECK(std::strcmp(node2.snapshot().status,"NODE READY")==0);
 // A lost/rebooted node can rejoin through its own or the two-node health path.
 node1.reset();node2.reset();fakeNow=9300;finishProbe(3);
 CHECK(std::strcmp(node1.snapshot().status,"NODE READY")==0);CHECK(std::strcmp(node2.snapshot().status,"NODE READY")==0);
 // No health TX during an owned control session.
 fakeNow=13000;rover.own(true);rover.background();CHECK(!rover.snapshot().probeQueued);rover.own(false);
 // Missing Node 1: expire a probe without damaging direct-route lock.
 rover.background();auto lost=take(rover);CHECK(decode(lost).route==1);fakeNow+=221;rover.poll();CHECK(rover.snapshot().locked);
 auto poll=take(rover);CHECK(decode(poll).kind==mesh::POLL&&decode(poll).route==0);
 base.receive(poll);rover.receive(take(base));fakeNow+=3000;finishProbe(2);
 // Reception re-arms silently after a quiet node and rescues missed IRQ edges.
 fakeNow+=6000;auto before=node1.snapshot().rxStarts;node1.background();CHECK(node1.snapshot().rxStarts==before+1);
 node2.fault();CHECK(!node2.snapshot().radioOK);fakeNow+=2000;node2.recover();CHECK(node2.snapshot().radioOK);
}
void probeDoesNotConsumeCommands(){
 initialize();direct();fakeNow=3100;rover.background();auto p=take(rover);node1.receive(p);p=take(node1);
 base.mailbox();base.receive(p);p=take(base);CHECK(decode(p).kind==mesh::PROBE_REPLY);CHECK(decode(p).n==0);
 node1.receive(p);rover.receive(take(node1));
 // The next real direct poll still carries the pending neutral command.
 fakeNow+=100;rover.poll();base.receive(take(rover));p=take(base);CHECK(decode(p).kind==mesh::COMMAND);CHECK(decode(p).n==27);
}
void matchingAndRebootGuards(){
 initialize();direct();fakeNow=3100;rover.background();auto p=take(rover);node1.receive(p);p=take(node1);base.receive(p);auto reply=take(base);
 // Reboot between upstream and reply must reject an unmatched old response.
 node1.reset();node1.receive(reply);CHECK(std::strcmp(node1.snapshot().status,"NODE STANDBY")==0);CHECK(node1.snapshot().tx==0);
 std::vector<uint8_t> ignored;CHECK(!node1.emit(ignored));
 // Future probe repairs it without manual pairing/rebooting any other board.
 fakeNow=6200;finishProbe(2);fakeNow=9300;finishProbe(3);CHECK(std::strcmp(node1.snapshot().status,"NODE READY")==0);
}
void activePathReboot(){
 initialize();direct();std::vector<uint8_t> packet;
 // Drop three fresh direct challenge/reply exchanges; the next TX uses Node 1.
 for(int i=0;i<4;++i){fakeNow+=101;rover.poll();packet=take(rover);CHECK(decode(packet).route==(i<3?0:1));}
 node1.receive(packet);base.receive(take(node1));node1.receive(take(base));rover.receive(take(node1));
 CHECK(rover.snapshot().locked&&rover.snapshot().route==1);
 CHECK(std::strcmp(node1.snapshot().status,"NODE FORWARDING")==0);
 node1.reset();fakeNow+=101;rover.poll();node1.receive(take(rover));base.receive(take(node1));node1.receive(take(base));rover.receive(take(node1));
 CHECK(rover.snapshot().locked&&rover.snapshot().route==1);CHECK(std::strcmp(node1.snapshot().status,"NODE FORWARDING")==0);
}
void missedIrqAndRxFault(){
 initialize();rover.poll();auto packet=take(rover);node1.lostIrq(packet);
 CHECK(std::strcmp(node1.snapshot().status,"NODE STANDBY")==0);
 fakeNow+=6000;node1.failReceive(true);node1.background();CHECK(!node1.snapshot().radioOK);
 node1.failReceive(false);fakeNow+=2000;node1.recover();CHECK(node1.snapshot().radioOK);
}
int main(){joinsAndRejoins();probeDoesNotConsumeCommands();matchingAndRebootGuards();activePathReboot();missedIrqAndRxFault();std::cout<<checks<<" four-role network checks passed\n";}
