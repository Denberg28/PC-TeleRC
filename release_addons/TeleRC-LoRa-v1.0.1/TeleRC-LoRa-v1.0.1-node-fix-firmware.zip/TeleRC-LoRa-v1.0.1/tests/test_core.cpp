#include <cassert>
#include <iostream>
#include <vector>
#define TELERC_ROLE 3
#define TELERC_NETWORK_ID 1
#include "RelayRoute.h"
#include "AutoRoute.h"
static unsigned checks=0;
#define CHECK(x) do {assert(x);++checks;} while(0)
std::vector<uint8_t> rc(uint16_t left,uint16_t right){
 std::vector<uint8_t> f(26);f[0]=0xfe;f[1]=18;f[3]=255;f[4]=190;f[5]=70;
 for(int i=0;i<8;++i)mesh::put16(f.data()+6+i*2,i==0?left:i==1?right:65535);
 f[22]=f[23]=1;telerc::CommandMailbox::checksumRc(f.data());return f;
}
void routes(){
 uint8_t key[32]={1};
 for(uint8_t mask=0;mask<4;++mask){
  uint16_t path[4];uint8_t count=relay::chain(mask,path);
  CHECK(count==autoroute::legs(mask)+1);
  for(uint8_t kind: {mesh::POLL,mesh::COMMAND,mesh::PROBE,mesh::PROBE_REPLY}){
   mesh::Packet p;p.network=1;p.route=mask;p.kind=kind;p.token=42;p.limit=p.hops=count-1;
   p.sender=p.origin=mesh::upstream(kind)?2:1;p.dest=mesh::upstream(kind)?1:2;
   for(uint8_t step=1;step<count;++step){
    uint8_t i=mesh::upstream(kind)?count-1-step:step;uint16_t self=path[i];
    uint8_t bytes[mesh::MAX];size_t n=mesh::seal(p,key,bytes);CHECK(n==mesh::HEADER+mesh::TAG);
    mesh::Packet q;CHECK(mesh::open(bytes,n,key,q));CHECK(q.route==mask);CHECK(relay::addressedTo(q,self));
    for(uint16_t other:{uint16_t(1),uint16_t(2),uint16_t(3),uint16_t(4)})if(other!=self)CHECK(!relay::addressedTo(q,other));
    if(self==3||self==4){CHECK(relay::forwardAs(q,self));p=q;}else CHECK(q.hops==1);
   }
  }
 }
 mesh::Packet p;p.network=1;p.route=3;p.kind=mesh::POLL;p.token=2;p.origin=p.sender=2;p.dest=1;p.limit=p.hops=3;
 uint8_t bytes[mesh::MAX];size_t n=mesh::seal(p,key,bytes);
 for(size_t i=0;i<n;++i){bytes[i]^=1;mesh::Packet q;CHECK(!mesh::open(bytes,n,key,q));bytes[i]^=1;}
 uint8_t wrong[32]={2};mesh::Packet q;CHECK(!mesh::open(bytes,n,wrong,q));
 mesh::Seen seen;CHECK(seen.admit(p,100));CHECK(!seen.admit(p,200));CHECK(seen.admit(p,4100));
 p.limit=2;CHECK(!relay::addressedTo(p,4));p.limit=3;p.network=2;CHECK(!relay::addressedTo(p,4));
}
void discovery(){
 autoroute::Discovery d;CHECK(d.mask()==0);CHECK(!d.locked);
 for(int i=0;i<8;++i){CHECK(d.missed());CHECK(d.mask()==(i+1)%4);}
 d.connected();CHECK(d.locked);CHECK(!d.missed());CHECK(!d.missed());CHECK(d.missed());CHECK(!d.locked);
 d.connected();d.missed();d.connected();CHECK(!d.missed());CHECK(d.mask()==1);
 d.reset();CHECK(!d.locked&&d.mask()==0);
}
void safety(){
 mesh::Safety s;auto drive=rc(1700,1800),center=rc(1500,1500),sparse=rc(1600,65535);
 CHECK(!s.rc(drive.data(),drive.size(),1));CHECK(s.rc(center.data(),center.size(),10));CHECK(s.centered(10));
 CHECK(s.rc(drive.data(),drive.size(),20));CHECK(!s.centered(20));CHECK(!s.expired(519));CHECK(s.expired(520));
 s.latch();CHECK(!s.ready&&!s.owned);CHECK(!s.rc(drive.data(),drive.size(),521));
 CHECK(s.rc(center.data(),center.size(),600));CHECK(s.rc(sparse.data(),sparse.size(),950));CHECK(s.expired(1100));
 s.latch();CHECK(s.rc(center.data(),center.size(),0xfffffff0));CHECK(!s.expired(100));CHECK(s.expired(500));
 mesh::Challenge c;c.issue(123,100,360);CHECK(c.pending(460));CHECK(!c.consume(124,200));CHECK(c.consume(123,460));CHECK(!c.consume(123,460));
 c.issue(42,0xfffffff0,90);CHECK(c.consume(42,50));c.issue(9,0,90);CHECK(!c.consume(9,91));
 telerc::CommandMailbox box;CHECK(box.accept(center.data(),center.size(),100));uint8_t out[96];CHECK(box.take(out,301)==0);
 CHECK(box.accept(center.data(),center.size(),400));CHECK(box.take(out,400)==27);CHECK(telerc::validBundle(out,27));
 out[0]=48;CHECK(!telerc::validBundle(out,27));
 auto release=rc(0,0);CHECK(box.accept(release.data(),release.size(),500));CHECK(!box.accept(drive.data(),drive.size(),501));
 CHECK(box.take(out,501)==27);
}
void framing(){
 const uint8_t in[]={1,2,3};uint8_t frame[32];size_t n=telerc::encodeUart(in,3,frame);CHECK(n==9);
 telerc::UartParser p;for(size_t i=0;i<n;++i)CHECK(p.feed(frame[i],100)==(i==n-1));CHECK(p.length()==3);
 frame[5]^=1;for(size_t i=0;i<n;++i)CHECK(!p.feed(frame[i],200));
 CHECK(!p.feed(0xa5,300));CHECK(!p.feed(0x5a,400)); // expired partial frame
}
void probeIsolation(){
 uint8_t key[32]={1},bytes[mesh::MAX];mesh::Packet p;
 p.kind=mesh::PROBE;p.network=1;p.route=1;p.origin=p.sender=2;p.dest=1;p.limit=p.hops=2;p.token=99;
 CHECK(mesh::seal(p,key,bytes)>0);p.owned=1;CHECK(!mesh::seal(p,key,bytes));p.owned=0;
 p.n=1;CHECK(!mesh::seal(p,key,bytes));p.n=0;
 const size_t n=mesh::seal(p,key,bytes);bytes[24]=1;
 uint8_t tag[32];CHECK(!mbedtls_md_hmac(mbedtls_md_info_from_type(MBEDTLS_MD_SHA256),key,32,bytes,mesh::HEADER,tag));
 memcpy(bytes+mesh::HEADER,tag,mesh::TAG);mesh::Packet q;CHECK(!mesh::open(bytes,n,key,q));
}
int main(){routes();discovery();safety();framing();probeIsolation();std::cout<<checks<<" core checks passed\n";}
