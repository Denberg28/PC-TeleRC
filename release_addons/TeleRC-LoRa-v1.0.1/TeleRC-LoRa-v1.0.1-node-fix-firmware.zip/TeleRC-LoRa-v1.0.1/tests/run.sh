#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
result_dir="$(mktemp -d)"
trap 'rm -rf "$result_dir"' EXIT
g++ -std=c++17 -Wall -Wextra -Werror -fsanitize=address,undefined -Itests/compat -Ifirmware/TeleRCLoRa_ROVER tests/test_core.cpp -lcrypto -o "$result_dir/core"
ASAN_OPTIONS=detect_leaks=0 "$result_dir/core"
g++ -std=c++17 -Wall -Wextra -Werror -Wno-unused-parameter -fsanitize=address,undefined -Itests/compat -Ifirmware/TeleRCLoRa_ROVER tests/test_link.cpp -lcrypto -o "$result_dir/link"
ASAN_OPTIONS=detect_leaks=0 "$result_dir/link"
g++ -std=c++17 -Wall -Wextra -Werror -Wno-unused-parameter -fsanitize=address,undefined -Itests/compat -Ifirmware/TeleRCLoRa_ROVER tests/test_wifi.cpp -lcrypto -o "$result_dir/wifi"
ASAN_OPTIONS=detect_leaks=0 "$result_dir/wifi"
for entry in '1 1 baseState baseApi' '3 1 roverState roverApi' '2 1 node1State node1Api' '2 2 node2State node2Api'; do
  read -r role index instance api <<< "$entry"
  g++ -std=c++17 -Wall -Wextra -Werror -Wno-unused-parameter -fsanitize=address,undefined -Itests/compat -Ifirmware/TeleRCLoRa_ROVER -DTELERC_ROLE="$role" -DTELERC_NODE_INDEX="$index" -DINSTANCE="$instance" -DAPI_NAME="$api" -c tests/role_instance.cpp -o "$result_dir/$instance.o"
done
g++ -std=c++17 -Wall -Wextra -Werror -fsanitize=address,undefined -Itests/compat -Ifirmware/TeleRCLoRa_ROVER tests/test_network.cpp "$result_dir/"*.o -lcrypto -o "$result_dir/network"
ASAN_OPTIONS=detect_leaks=0 "$result_dir/network"
