#pragma once
#include <vector>
#include <stdint.h>
struct RoleSnapshot {
 unsigned owned=0,route=0,received=0,tx=0,rejected=0,rxStarts=0;
 bool locked=false,probeWaiting=false,probeQueued=false,radioOK=false,known1=false,known2=false;
 const char* status="";
};
struct RoleApi {
 void(*reset)();void(*receive)(const std::vector<uint8_t>&);
 bool(*emit)(std::vector<uint8_t>&);void(*poll)();void(*background)();
 void(*own)(bool);void(*mailbox)();void(*fault)();void(*recover)();
 RoleSnapshot(*snapshot)();
 void(*lostIrq)(const std::vector<uint8_t>&);void(*failReceive)(bool);
};
RoleApi baseApi();RoleApi roverApi();RoleApi node1Api();RoleApi node2Api();
