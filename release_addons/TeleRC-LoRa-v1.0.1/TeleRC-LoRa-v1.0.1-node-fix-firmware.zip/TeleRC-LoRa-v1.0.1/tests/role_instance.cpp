#include "Arduino.h"
#include <algorithm>
#include <cctype>
#include "SPI.h"
#include "RadioLib.h"
#include "Preferences.h"
#include "esp_system.h"
#include "MeshCore.h"
#include "LinkLed.h"
#include "Pairing.h"
#include "AutoRoute.h"
#include "NodeState.h"
#include "role_api.h"
#define TELERC_RUNTIME_MENU 1
namespace INSTANCE {
#include "Link.h"
void resetRole(){
 safety={};commands={};seen={};challenge={};discovery={};nodeState={};probeChallenge={};
 activeRoute=probeRoute=probeIndex=0;probeQueued=probeInFlight=false;probeAt=0;rxAt=rxRearmAt=millis();
 nodeKnown[0]=nodeKnown[1]=false;nodeAt[0]=nodeAt[1]=0;
 vehicle.bytes.clear();vehicle.room=1024;vehicle.shortNext=false;
 haveFc=true;fcAt=millis();radioOK=true;maintenance=transmitting=scanning=awaitingReply=stopPending=false;
 pollInFlight=false;radioIRQ=false;pollAt=0;clearQueue();usbHead=usbTail=usbCount=0;
 cfg=Config{};cfg.key[0]=1;cfg.khz=915000;
 radio.incoming.clear();radio.sent.clear();radio.beginResult=radio.rxResult=0;
 rxCount=txCount=rejectCount=txFail=0;linkLed={};
}
void receiveRole(const std::vector<uint8_t>&in){radio.incoming=in;radioIRQ=true;pumpRadio();}
bool emitRole(std::vector<uint8_t>&out){
 if(transmitting||scanning)return false;
 fakeNow+=3;radio.sent.clear();pumpTx();
 if(!scanning)return false;
 radioIRQ=true;pumpRadio();if(!transmitting)return false;
 out=radio.sent;radioIRQ=true;pumpRadio();return true;
}
void backgroundRole(){recoverReceive();sendProbe();}
void lostIrqRole(const std::vector<uint8_t>&in){radio.incoming=in;radioIRQ=false;fakeDio=HIGH;recoverReceive();fakeDio=LOW;pumpRadio();}
void failReceiveRole(bool fail){radio.rxResult=fail?-1:0;}
void ownRole(bool owned){safety.owned=owned?3:0;safety.ready=owned;safety.at[0]=safety.at[1]=millis();}
void mailboxRole(){uint8_t f[26];makeRc(f,1500,0);commands.accept(f,sizeof(f),millis());}
RoleSnapshot snapshotRole(){
 RoleSnapshot s;s.owned=safety.owned;s.route=activeRoute;s.received=rxCount;s.tx=txCount;s.rejected=rejectCount;
 s.locked=discovery.locked;s.probeWaiting=probeChallenge.pending(millis());s.probeQueued=probeQueued;
 s.radioOK=radioOK;s.known1=nodeKnown[0];s.known2=nodeKnown[1];s.status=nodeState.status(millis());s.rxStarts=radio.rxCalls;return s;
}
}
RoleApi API_NAME(){
 return {INSTANCE::resetRole,INSTANCE::receiveRole,INSTANCE::emitRole,INSTANCE::sendPoll,
 INSTANCE::backgroundRole,INSTANCE::ownRole,INSTANCE::mailboxRole,INSTANCE::radioFault,INSTANCE::recoverRadio,INSTANCE::snapshotRole,INSTANCE::lostIrqRole,INSTANCE::failReceiveRole};
}
