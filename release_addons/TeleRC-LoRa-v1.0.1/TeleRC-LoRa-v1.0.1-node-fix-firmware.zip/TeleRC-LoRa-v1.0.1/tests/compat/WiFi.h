#pragma once
#include "Arduino.h"
struct IPAddress {
 uint8_t bytes[4];IPAddress(int a,int b,int c,int d):bytes{uint8_t(a),uint8_t(b),uint8_t(c),uint8_t(d)}{}
 uint8_t operator[](int i)const{return bytes[i];}
 bool operator==(const IPAddress&o)const{return memcmp(bytes,o.bytes,4)==0;}
 bool operator!=(const IPAddress&o)const{return !(*this==o);}
};
constexpr int WIFI_OFF=0,WIFI_AP=2;
struct WiFiMock {
 int stations=1,currentMode=0,starts=0;bool canStart=true;
 IPAddress ip{0,0,0,0};
 int softAPgetStationNum(){return stations;}
 bool mode(int mode){currentMode=mode;return true;}
 int getMode(){return currentMode;}
 IPAddress softAPIP(){return ip;}
 bool softAPConfig(IPAddress wanted,IPAddress,IPAddress){ip=wanted;return true;}
 bool softAP(const char*,const char*,int,int,int){++starts;return canStart;}
};
inline WiFiMock WiFi;
