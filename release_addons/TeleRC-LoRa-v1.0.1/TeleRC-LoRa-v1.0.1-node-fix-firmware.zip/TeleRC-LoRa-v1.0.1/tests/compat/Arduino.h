#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <algorithm>
#define HIGH 1
#define LOW 0
#define OUTPUT 1
#define INPUT_PULLUP 2
#define SERIAL_8N1 0
#define IRAM_ATTR
inline uint32_t fakeNow=100;
inline uint32_t millis(){return fakeNow;}
inline void delay(unsigned n){fakeNow+=n;}
inline void pinMode(int,int){}
inline void digitalWrite(int,int){}
inline int fakeDio=LOW;
inline int digitalRead(int pin){return pin==33?fakeDio:HIGH;}
class HardwareSerial {
 public:
 std::vector<uint8_t> bytes;int room=1024;bool shortNext=false;
 HardwareSerial(int){}
 void begin(int,int=0,int=0,int=0){}
 void setRxBufferSize(int){}void setTxBufferSize(int){}
 void setTxTimeoutMs(int){}
 int availableForWrite(){return room;}
 int available(){return 0;}int read(){return -1;}
 size_t write(const uint8_t*p,size_t n){size_t k=std::min(n,size_t(std::max(room,0)));if(shortNext&&k){--k;shortNext=false;}bytes.insert(bytes.end(),p,p+k);return k;}
};
inline HardwareSerial Serial(0);
