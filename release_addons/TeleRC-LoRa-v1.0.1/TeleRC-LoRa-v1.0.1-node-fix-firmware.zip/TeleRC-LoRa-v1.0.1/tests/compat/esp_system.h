#pragma once
inline uint32_t esp_random(){static uint32_t n=123;return ++n;}
inline int esp_reset_reason(){return 1;}
