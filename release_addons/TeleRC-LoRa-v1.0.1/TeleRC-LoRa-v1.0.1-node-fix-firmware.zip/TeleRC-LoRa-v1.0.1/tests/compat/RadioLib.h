#pragma once
#define RADIOLIB_ERR_NONE 0
#define RADIOLIB_LORA_DETECTED 1
#define RADIOLIB_CHANNEL_FREE 2
struct Module {Module(int,int,int,int){}};
struct SX1262 {
 int beginResult=0,beginCalls=0,rxResult=0,rxCalls=0;
 int scanResult=RADIOLIB_CHANNEL_FREE;
 std::vector<uint8_t> incoming,sent;
 SX1262(Module*){}
 int begin(float,float,int,int,int,int,int,float){++beginCalls;return beginResult;}
 int setRxBoostedGainMode(bool,bool){return 0;}
 void setDio1Action(void(*)()){}
 int startReceive(){++rxCalls;return rxResult;}
 int standby(){return 0;}
 int startChannelScan(){return 0;}
 int getChannelScanResult(){return scanResult;}
 int startTransmit(uint8_t*p,size_t n){sent.assign(p,p+n);return 0;}
 int finishTransmit(){return 0;}
 size_t getPacketLength(){return incoming.size();}
 int readData(uint8_t*p,size_t n){memcpy(p,incoming.data(),n);return 0;}
 unsigned getTimeOnAir(size_t n){return 1000*n/3;}
};
