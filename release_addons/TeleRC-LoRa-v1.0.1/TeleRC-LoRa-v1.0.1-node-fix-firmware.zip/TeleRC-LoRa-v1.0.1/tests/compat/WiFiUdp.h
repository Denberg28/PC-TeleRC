#pragma once
#include "WiFi.h"
struct WiFiUDP {
 bool ready=false;int begins=0;
 IPAddress sender{192,168,4,2};uint16_t port=14550;std::vector<uint8_t> in;
 bool begin(int){++begins;ready=true;return true;}
 void stop(){ready=false;in.clear();}
 int beginPacket(IPAddress,int){return true;}
 size_t write(const uint8_t*,size_t n){return n;}
 int endPacket(){return true;}
 int parsePacket(){return in.size();}
 IPAddress remoteIP(){return sender;}uint16_t remotePort(){return port;}
 int read(uint8_t*out,size_t n){size_t count=std::min(n,in.size());memcpy(out,in.data(),count);in.erase(in.begin(),in.begin()+count);return count;}
 int available(){return in.size();}int read(){if(in.empty())return -1;int b=in.front();in.erase(in.begin());return b;}
};
