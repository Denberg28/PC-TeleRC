#pragma once
// Host-only adapter: exercise the actual packet codec using OpenSSL SHA-256.
#include <openssl/hmac.h>
#define MBEDTLS_MD_SHA256 6
inline const EVP_MD* mbedtls_md_info_from_type(int){return EVP_sha256();}
inline int mbedtls_md_hmac(const EVP_MD*md,const unsigned char*key,size_t kn,const unsigned char*in,size_t n,unsigned char*out){
 unsigned size=0;return HMAC(md,key,int(kn),in,n,out,&size)&&size==32?0:-1;
}
