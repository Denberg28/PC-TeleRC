#pragma once
#include "md.h"
#include <openssl/evp.h>
inline int mbedtls_pkcs5_pbkdf2_hmac_ext(int,const unsigned char*p,size_t n,const unsigned char*s,size_t sn,unsigned it,unsigned kn,unsigned char*out){return PKCS5_PBKDF2_HMAC(reinterpret_cast<const char*>(p),n,s,sn,it,EVP_sha256(),kn,out)==1?0:-1;}
