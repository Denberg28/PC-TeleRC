#pragma once
#include <stdint.h>
#include <stddef.h>
#ifndef TELERC_LORA_PASSWORD
#define TELERC_LORA_PASSWORD "telerc123"
#endif
#ifndef TELERC_LORA_FREQUENCY_KHZ
#define TELERC_LORA_FREQUENCY_KHZ 915000
#endif
#ifndef TELERC_LORA_POWER_DBM
#define TELERC_LORA_POWER_DBM 2
#endif
#ifndef TELERC_NETWORK_ID
#define TELERC_NETWORK_ID 1
#endif
#ifndef TELERC_NODE_INDEX
#define TELERC_NODE_INDEX 1
#endif
namespace settings {
inline constexpr char VERSION[]="1.0.0";
inline constexpr char PASSWORD[]=TELERC_LORA_PASSWORD;
constexpr bool COMPILED_PAIRING=true;
constexpr uint8_t NODE_INDEX=TELERC_NODE_INDEX;
constexpr uint16_t SELF=TELERC_ROLE==1?1:TELERC_ROLE==3?2:uint16_t(2+NODE_INDEX);
constexpr bool visiblePassword(){
 if(sizeof(PASSWORD)<9||sizeof(PASSWORD)>33)return false;
 for(size_t i=0;i+1<sizeof(PASSWORD);++i)if(uint8_t(PASSWORD[i])<33||uint8_t(PASSWORD[i])>126)return false;
 return true;
}
static_assert(visiblePassword(),"Use 8-32 visible ASCII characters without spaces");
static_assert(TELERC_ROLE>=1&&TELERC_ROLE<=3,"Select BASE=1, NODE=2 or ROVER=3");
static_assert(TELERC_ROLE!=2||(NODE_INDEX==1||NODE_INDEX==2),"NODE_INDEX must be 1 or 2");
static_assert(TELERC_NETWORK_ID>=1&&TELERC_NETWORK_ID<=65535,"Network ID must be 1..65535");
static_assert(TELERC_LORA_FREQUENCY_KHZ>=830250&&TELERC_LORA_FREQUENCY_KHZ<=944750,"Use the 868/915 MHz SX1262 hardware band");
static_assert(TELERC_LORA_POWER_DBM>=2&&TELERC_LORA_POWER_DBM<=17,"Power must be 2..17 dBm");
}
