#pragma once
#include <Arduino.h>
#include <algorithm>
#include <cctype>
#include <SPI.h>
#include <RadioLib.h>
#include <Preferences.h>
#include <esp_system.h>
#include "MeshCore.h"
#include "LinkLed.h"
#include "LinkMode.h"
#include "Pairing.h"
#include "BootMenu.h"
#include "TinyOled.h"
#include "SketchSettings.h"
#include "RelayRoute.h"
// BASE/NODE builds have no Wi-Fi, UDP or web portal implementation.
#if TELERC_ROLE == 3
#include <WiFi.h>
#include <WiFiUdp.h>
#endif
#define TELERC_RUNTIME_MENU 1
namespace lora {
#include "Link.h"
}
#if TELERC_ROLE == 3
namespace wifi {
#include "WiFiLink.h"
}
#endif
namespace runtime {
constexpr uint8_t WIFI_MODE=1,LORA_MODE=0;
constexpr uint32_t RESTART_MIN_PAUSE_MS=16000,SCREEN_IDLE_MS=30000;
telerc::BootButton button;telerc::TinyOled oled;
uint8_t mode=LORA_MODE,choice=0;
bool menu=false,statusPage=false,restarting=false,wakeGesture=false;
uint32_t screenAt=0,pausedAt=0,paintedAt=0,restartAt=0;
const char*notice="";
const char*roleName(){return TELERC_ROLE==1?"BASE":TELERC_ROLE==2?(TELERC_NODE_INDEX==1?"NODE 1":"NODE 2"):"ROVER";}
bool pendingStop(){
#if TELERC_ROLE == 3
 if(mode==WIFI_MODE)return wifi::stopMask!=0;
#endif
 return lora::stopPending;
}
bool saveMode(uint8_t selected){
#if TELERC_ROLE == 3
 Preferences p;if(!p.begin("telerc-ui",false))return false;
 bool ok=p.putUChar("mode",selected)==1;p.end();return ok;
#else
 return selected==LORA_MODE;
#endif
}
void paint(){
 char title[24],modeLine[24],count[40],freq[24],route[24];
 snprintf(title,sizeof(title),"TELERC %s V1.0",roleName());
 snprintf(modeLine,sizeof(modeLine),"MODE: %s",mode==WIFI_MODE?"WI-FI":"LORA");
 snprintf(freq,sizeof(freq),"%lu.%03lu MHZ",(unsigned long)(lora::cfg.khz/1000),(unsigned long)(lora::cfg.khz%1000));
 snprintf(route,sizeof(route),"ID:%u NET:%u",unsigned(settings::SELF),unsigned(TELERC_NETWORK_ID));
 const char*rows[8]={title,modeLine,freq,"","","",route,""};
 if(restarting){
  uint32_t elapsed=millis()-pausedAt;
  uint32_t remaining=elapsed<RESTART_MIN_PAUSE_MS?(RESTART_MIN_PAUSE_MS-elapsed+999)/1000:0;
  snprintf(count,sizeof(count),"RESTART IN %lu S",(unsigned long)remaining);
  rows[2]="CONTROL STOPPED";rows[3]=count;rows[4]="REENABLE MANUALLY";
 }else if(menu&&!statusPage){
#if TELERC_ROLE == 3
  const char*items[]={"> WI-FI","> LORA","> STATUS","> EXIT / RESTART"};
#else
  const char*items[]={"> STATUS","> EXIT / RESTART"};
#endif
  rows[2]="CONTROL STOPPED";rows[3]=items[choice];rows[4]="TAP: NEXT";rows[5]="HOLD: SELECT";
  rows[7]=pendingStop()?"STOP WRITE PENDING":notice;
 }else{
#if TELERC_ROLE == 3
  if(mode==WIFI_MODE){
   snprintf(count,sizeof(count),"FC:%u CLIENTS:%u",unsigned(wifi::freshFc(millis())),unsigned(WiFi.softAPgetStationNum()));
   rows[3]=count;rows[4]=wifi::safety.owned?"CONTROL ACTIVE":"CONTROL OFF";rows[7]="192.168.4.1:14550";
  }else
#endif
  {
   snprintf(count,sizeof(count),"RX:%lu TX:%lu",(unsigned long)lora::rxCount,(unsigned long)lora::txCount);
   rows[3]=count;
   rows[4]=lora::maintenance?"CONTROL PAUSED":!lora::radioOK?"RADIO RETRY":lora::linkLed.havePeer&&uint32_t(millis()-lora::linkLed.peerAt)<1500?(TELERC_ROLE==3?"LINK CONNECTED":"PEER TRAFFIC"):"AUTO CONNECTING";
   rows[7]=autoroute::name(lora::activeRoute);
  }
  rows[5]=menu?"TAP: BACK":"HOLD BOOT: MENU";
 }
 oled.rows(rows);paintedAt=millis();
}
void pause(){
 menu=true;statusPage=false;pausedAt=millis();choice=0;notice="";
#if TELERC_ROLE == 3
 if(mode==WIFI_MODE){wifi::stopControl("setup");wifi::udp.stop();wifi::udpReady=false;}
 else
#endif
 {lora::stopControl(4);if(lora::radioOK)lora::radio.standby();lora::radioOK=false;lora::transmitting=lora::scanning=false;}
 lora::maintenance=true;paint();
}
bool restart(uint8_t selected){
 if(!menu||pendingStop()){notice="WAIT FOR STOP WRITE";paint();return false;}
 if(!saveMode(selected)){notice="STORAGE FAILED";paint();return false;}
 mode=selected;restarting=true;restartAt=millis();paint();return true;
}
void select(){
#if TELERC_ROLE == 3
 if(choice<2){restart(choice==0?WIFI_MODE:LORA_MODE);return;}
 if(choice==2){statusPage=true;paint();return;}
#else
 if(choice==0){statusPage=true;paint();return;}
#endif
 restart(mode);
}
void setup(){
 pinMode(0,INPUT_PULLUP);lora::loadConfig();
 mode=LORA_MODE;
#if TELERC_ROLE == 3
 mode=TELERC_TRANSPORT_WIFI;
 Preferences p;if(p.begin("telerc-ui",true)){uint8_t saved=p.getUChar("mode",mode);if(saved<=1)mode=saved;p.end();}
#endif
 oled.begin();
#if TELERC_ROLE == 3
 if(mode==WIFI_MODE)wifi::setup();else
#endif
 lora::setup(true);
 screenAt=millis();paint();
}
void loop(){
 uint32_t now=millis();telerc::Press event=button.update(digitalRead(0)==LOW,now);
 if(button.raw||button.stable)screenAt=now;
 if(oled.asleep&&button.stable){oled.setAwake(true);wakeGesture=true;paint();}
 if(wakeGesture){event=telerc::Press::NONE;if(!button.raw&&!button.stable)wakeGesture=false;}
 if(!menu){
  if(event==telerc::Press::HOLD){pause();event=telerc::Press::NONE;}
  if(!menu){
#if TELERC_ROLE == 3
   if(mode==WIFI_MODE)wifi::loop();else
#endif
   lora::loop();
  }
 }
 if(menu){
  if(pendingStop()){
#if TELERC_ROLE == 3
   if(mode==WIFI_MODE){if(uint32_t(now-wifi::lastStopTry)>=100)wifi::tryStop();}else
#endif
   if(uint32_t(now-lora::lastStopTry)>=100)lora::tryStop();
  }
  if(mode==LORA_MODE){lora::pumpUsb();lora::serviceUsbTx();}
  if(!restarting){
   if(event==telerc::Press::TAP){if(statusPage)statusPage=false;else choice=(choice+1)%(TELERC_ROLE==3?4:2);paint();}
   if(event==telerc::Press::HOLD){if(!statusPage)select();else{statusPage=false;paint();}}
  }
  if(restarting&&!pendingStop()&&uint32_t(now-pausedAt)>=RESTART_MIN_PAUSE_MS&&uint32_t(now-restartAt)>=1000){ESP.restart();return;}
  lora::serviceLed();delay(1);
 }
 if(uint32_t(now-paintedAt)>=1000)paint();
 if(!button.raw&&!button.stable&&!oled.asleep&&uint32_t(now-screenAt)>=SCREEN_IDLE_MS)oled.setAwake(false);
 oled.step();
}
}
