# TeleRC LoRa / Wi-Fi firmware v1.0.0

Reviewed update of the supplied `TeleRC-LoRa-915-PnP-v0.1.3-sketches.zip` for
**LilyGO T3-S3 SX1262, 868/915 MHz hardware**. Includes source for four boards.
All four sketches have passed ESP32 target compilation; physical RF, UART,
Windows COM connection, range and motor failsafe tests remain to be performed.
This is a firmware build, not an application release or a hardware-validated
stable release.

## Choose the matching sketch

| Board | Open this sketch | Transport | Radio identity |
| --- | --- | --- | --- |
| PC base | `firmware/TeleRCLoRa_BASE/TeleRCLoRa_BASE.ino` | LoRa only; native USB to PC | 1 |
| Rover | `firmware/TeleRCLoRa_ROVER/TeleRCLoRa_ROVER.ino` | Choose Wi-Fi or LoRa | 2 |
| Node 1 | `firmware/TeleRCLoRa_NODE1/TeleRCLoRa_NODE1.ino` | LoRa only | 3 |
| Node 2 | `firmware/TeleRCLoRa_NODE2/TeleRCLoRa_NODE2.ino` | LoRa only | 4 |

**Flash every participating LoRa board from this v1.0.0 package.** The automatic
route header uses radio protocol v3. Old v0.1.3 boards use protocol v2 and will
not link with this build. One base, one rover and at most one of each node ID
are supported on this network. Never flash NODE1 onto both relay boards.

## Shared plug-and-play settings

| Setting | Default |
| --- | --- |
| Frequency | 915.000 MHz |
| LoRa password | `telerc123` (nine characters) |
| Network ID | 1 |
| Transmit power | 2 dBm, retained from the supplied working preset |
| Modulation | SF7, BW500 kHz, CR4:5, private sync 0x12 |
| Rover initial transport | LoRa; an existing saved choice takes priority |
| Wi-Fi SSID / password | `TeleRC-Rover` / `telerc123` |
| Wi-Fi endpoint | 192.168.4.1, UDP 14550 |
| FC UART / PC USB baud | 115200 |

No pairing button, web page, relay-count entry or password entry is needed
with these defaults. Power the boards in any order. Base and nodes contain no
Wi-Fi AP, UDP or web configuration path. Frequency, LoRa password, network ID
and power are edited in each `.ino` before upload. Keep frequency, password
and network ID identical across every board. Passwords accept 8–32 visible
ASCII characters without spaces. Changing the Wi-Fi password is separate:
edit `AP_PASSWORD` in the rover's `WiFiLink.h`.

## Flash with Arduino IDE

1. Disconnect motor power and attach a suitable antenna to every radio.
2. Install **esp32 by Espressif Systems 3.3.2** and **RadioLib 7.2.1**.
3. Select **LilyGo T3-S3**, Board Revision **Radio-SX1262**, USB CDC On Boot
   **Enabled**, USB Mode **Hardware CDC and JTAG**, PSRAM **Enabled**, default
   4 MB partition scheme, Erase All Flash **Disabled**.
4. Open the appropriate `.ino` above. Keep its entire adjacent header folder.
   Upload to the matching board's current COM port.
5. Reset with BOOT released. Close Serial Monitor before opening PC TeleRC.

The ZIP also includes optional compiled factory images; see
`binaries/FLASHING.md`. Uploading source through Arduino IDE preserves the
rover's saved transport when flash erase is disabled.

## LoRa automatic connection

The rover probes these paths in order:

1. BASE ↔ ROVER, directly.
2. BASE ↔ NODE1 ↔ ROVER.
3. BASE ↔ NODE2 ↔ ROVER.
4. BASE ↔ NODE1 ↔ NODE2 ↔ ROVER.

It selects the first path returning an authenticated reply. Nodes automatically
forward only packets addressed to their position on that path. They need only
power and an antenna; no Wi-Fi or PC connection. With two relays, place Node 1
closer to the base and Node 2 closer to the rover. Either node can also work
alone. There is no broadcast flooding, arbitrary mesh or reverse node order.

A working path stays selected. Three unanswered challenges release it and
continue the search. It does not periodically interrupt control to try a
shorter path. Restart the rover when stopped if you want a fresh direct-first
search. During interference, discovery can take longer; it has no RF timing or
range guarantee. A failed radio initialization or RX/TX operation is retried
after at least two seconds. A missing peer does not repeatedly reset a healthy
radio.

The base responds automatically when it receives a valid rover poll, even if
the PC app has not connected. This establishes the RF path only. To operate,
connect BASE by USB, open its COM port in PC TeleRC's LilyGO/LoRa profile, and
wait for the **real flight-controller heartbeat**. The firmware cannot select
or open a Windows COM port for the application.

## Rover Wi-Fi / LoRa selection

While running, hold **BOOT** for about one second to enter the menu. If the
screen is asleep, first tap BOOT to wake it; that wake gesture is ignored by
the menu. Tap to select **WI-FI** or **LORA**, then hold to confirm. Operation
pauses on menu entry; a restart waits at least 16 seconds from menu entry so
an old host session can time out. The choice is saved across reboots/uploads.

In Wi-Fi mode, join `TeleRC-Rover` with password `telerc123` on the phone/PC,
then connect the app to UDP 14550. The rover automatically starts/retries its
AP and UDP listener. Joining the SSID and opening the app connection still
happen on the phone/PC. The base and relay nodes are not used in this mode.
A healthy AP stays up while there are no clients. In LoRa mode, Wi-Fi is not
started. The firmware never changes between Wi-Fi and LoRa by itself.

OLED sleeps after 30 seconds; communication keeps running. LED blinks while
waiting and remains on for recent authenticated radio traffic (or accepted
Wi-Fi traffic with a fresh FC heartbeat). A node's LED/PEER TRAFFIC means it
has heard traffic; confirm end-to-end connection and FC heartbeat at the app.
A missing OLED does not prevent link operation.

## Rover wiring and control limits

Keep the supplied LilyGO rover wiring:

| Connection | Pin |
| --- | --- |
| SpeedyBee T3 → LilyGO RX | GPIO44 |
| SpeedyBee R3 ← LilyGO TX | GPIO43 |
| Common ground | GND |
| OLED SDA / SCL | GPIO18 / GPIO17 (onboard) |

Use 3.3 V UART logic, MAVLink2/115200 on the FC telemetry port and your known
working ArduRover configuration. This is an FC bridge; it does not drive motor
drivers directly. Firmware control targets MAVLink system/component **1/1**,
GCS source **255/190**, CH1 steering and CH2 throttle. Other override channels
are ignored/rejected so auxiliary receiver takeover channels are preserved.
Receiver takeover and vehicle stopping still depend on the FC configuration.

Connection recovery never arms the rover. Motion commands are rejected until
both axes are centered at 1500 ±25 µs and a fresh FC heartbeat is present.
Each controlled axis must continue receiving fresh commands; heartbeat or
telemetry alone cannot renew it. At 500 ms without axis updates the bridge
latches control off and attempts neutral followed by override release. FC
heartbeat age of 2.5 seconds also releases owned control. UART output failures
retry the release; physical FC stopping cannot be guaranteed by a UART write.
Reconnect at neutral and deliberately re-enable control in the app. This
bridge checks neutral/freshness; ArduPilot remains responsible for its own
arming checks. Configure and test the FC's independent RC/GCS failsafes for
bridge power loss, UART loss and receiver loss.

## Compatibility boundary

PC USB framing and existing TeleRC Wi-Fi datagrams are retained. Host tests
exercise those codecs, but the current Android and Windows apps were not run
against physical hardware here. This build retains the supplied baseline's
command whitelist: discovery/disconnect, GCS heartbeat, MAVLink1 RC override
(CH1/CH2), and explicit arm/disarm. It relays selected FC telemetry and command
ACKs. **Mission upload/start, waypoint commands, F1/F2/F3 servo commands and
multi-rover fleet operation are not implemented by this attached baseline or
added in this firmware update.** Do not use it as a full MAVLink mission
telemetry modem.

LoRa packets use a 128-bit truncated HMAC-SHA256 tag, challenge-bound command
replies, a bounded replay cache and an authenticated directed route. Payloads
are not encrypted. The supplied password is public: use a different shared
password before operating outside a controlled test setup. Matching credentials
are required, but do not constitute individual node enrollment or revocation.

## First physical test

With wheels raised and a reachable motor cutoff, verify each path, power-up in
different orders, switching Wi-Fi/LoRa, loss/recovery of base/node/FC power,
USB closure, and loss of host axis commands. Confirm neutral/release and
transmitter takeover on your FC, then test at low speed on the ground.
Target compilation and host simulation cannot certify RF performance, power
integrity, motor stopping or app interoperability. See `REVIEW.md` and
`VALIDATION.json` for exact completed checks.
