# Review and changes — v1.0.0

Input: attached TeleRC-LoRa-915-PnP-v0.1.3-sketches.zip. Scope: the existing
single-rover LilyGO/ArduRover bridge, transport selection, automatic connection,
and two matching relay firmwares. No desktop/Android app or FC parameters were
changed. Review date: 23 October 2026 (Asia/Manila).

| Finding in supplied source | Result in v1.0.0 |
| --- | --- |
| Relay count is compiled on every participant; no node sketches supplied | Four directed routes are discovered automatically. Separate Node 1 and Node 2 sketches have unique IDs. |
| Radio init, RX, CAD or TX failure can leave RF permanently off until reset | Radio faults latch local control off, clear queued commands and retry initialization after at least 2 seconds. |
| BASE/NODE runtime contains a Wi-Fi setup portal | Removed portal. Wi-Fi headers/backend are compiled only for the rover. All builds use explicit sketch credentials. |
| Fixed relay sender/hop validation prevents optional-node paths | Authenticated route mask plus expected sender/hop checks supports direct, either single node and the ordered two-node chain. |
| LoRa records RC ownership only after the entire UART write succeeds | Ownership is recorded before writing, allowing a partial first RC write to trigger neutral/release. |
| A partially transmitted USB status frame can expire mid-frame | Expiry applies only before transmission begins, retaining frame boundaries for the host. |
| Rover reset can leave an earlier FC RC override alive until FC timeout | Rover startup attempts neutral + release before accepting new control. Both transports retry a pending release. |
| Wi-Fi setup page incorrectly describes the nine-character preset as eight | Portal removed; sketch validation and instructions consistently state 8–32 visible ASCII characters. |
| Package text points to an absent VALIDATION.json | Reproducible host checks, target build results, source hashes and validation limits are included. |

The original control whitelist, MAVLink target/source IDs, neutral gate,
500 ms axis watchdog, 2.5 s FC-heartbeat limit, fixed UDP port, 915 MHz preset,
2 dBm default, OLED timeout and nonblocking USB queue architecture are retained.
This release does not soften acceleration or bypass FC arming checks.

## Automatic-route design

The radio header is protocol v3: byte 23 authenticates the route mask (bit 0
Node 1, bit 1 Node 2). All other header widths, the 16-byte HMAC tag and PC USB
framing remain unchanged. Discovery starts direct, then Node 1, Node 2, both.
The challenge response window follows the actual route (90/220/360 ms for
1/2/3 legs). A working route stays locked until three unanswered challenges;
searching probes each candidate once before advancing. Hops only decrease and
nodes accept their expected neighbor, preventing forwarding loops/flooding.
Two-node order is always BASE→NODE1→NODE2→ROVER. Fixed maximum: two nodes.

Radio authentication does not encrypt payloads. Nodes share the network key;
compromise of a node or the public default password compromises network trust.
A bounded replay cache reduces repeated forwarding; the rover's one-use,
expiring challenge is the control replay defense. It does not use a timestamp
shared among boards. There is no over-the-air node management or fleet routing.

## Completed verification

- ESP32 3.3.2 + RadioLib 7.2.1 target compilation for BASE, ROVER, NODE1, NODE2.
- 272 core checks: authenticated round trips over all four routes, expected
  neighbors/hops, HMAC tampering/wrong key, network ID mismatch, replay cache,
  discovery lock/miss behavior, freshness, neutral gate, per-axis expiry,
  timer wraparound and serial framing.
- 31 checks against actual Link.h with simulated hardware: partial UART writes,
  pending stop retries, stop dominance, FC presence gate, radio recovery timing,
  menu maintenance blocking recovery, partial USB frame completion/expiry,
  route failure thresholds and matching/mismatched live challenges.
- 15 checks against actual WiFiLink.h with simulated hardware: AP startup and
  recovery, no AP restart for absent clients, FC/neutral gates, short UART
  write release, source IP/port checks, peer lock and axis timeout.
- AddressSanitizer and UndefinedBehaviorSanitizer enabled for host tests;
  LeakSanitizer disabled because this container restricts process inspection.

Host radio/Wi-Fi/serial APIs are mocks; the production packet codec and control
logic are the actual packaged headers. OpenSSL implements the host adapter for
mbedTLS SHA-256/HMAC/PBKDF2. This does not exercise the physical ESP32 hardware
or establish maximum execution/stop latency. Target compilation uses the real
Espressif and RadioLib libraries, not those mocks.

## Remaining checks on the rover

Physical range/interference, antenna and board variation, motor EMI/brownout,
UART wiring, actual stop behavior, receiver takeover, Android/Windows app
interoperability and COM availability require bench/field testing. The 500 ms
watchdog is the bridge's command-age threshold, not a certified physical
stopping-time guarantee. Reconnection alone grants no neutral/arming bypass;
neutral is required again after a stop. If the host remains enabled and sends
neutral then drive, the firmware can accept them: deliberate app control
re-enabling remains an operator/app workflow, not a new authorization protocol.

## Build references

- Espressif board variant/pin map used by target compilation:
  https://github.com/espressif/arduino-esp32/blob/3.3.2/variants/lilygo_t3_s3_sx1262/pins_arduino.h
- LilyGO board reference:
  https://wiki.lilygo.cc/products/t3-series/t3-s3-v1.3/
- RadioLib pinned SX126x implementation used in target compilation:
  https://github.com/jgromes/RadioLib/blob/7.2.1/src/modules/SX126x/SX126x.cpp
