#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
result_dir="$(mktemp -d)"
trap 'rm -rf "$result_dir"' EXIT
g++ -std=c++17 -Wall -Wextra -Werror -fsanitize=address,undefined -Itests/compat -Ifirmware/TeleRCLoRa_ROVER tests/test_core.cpp -lcrypto -o "$result_dir/core"
ASAN_OPTIONS=detect_leaks=0 "$result_dir/core"
g++ -std=c++17 -Wall -Wextra -Werror -Wno-unused-parameter -fsanitize=address,undefined -Itests/compat -Ifirmware/TeleRCLoRa_ROVER tests/test_link.cpp -lcrypto -o "$result_dir/link"
ASAN_OPTIONS=detect_leaks=0 "$result_dir/link"
g++ -std=c++17 -Wall -Wextra -Werror -Wno-unused-parameter -fsanitize=address,undefined -Itests/compat -Ifirmware/TeleRCLoRa_ROVER tests/test_wifi.cpp -lcrypto -o "$result_dir/wifi"
ASAN_OPTIONS=detect_leaks=0 "$result_dir/wifi"
